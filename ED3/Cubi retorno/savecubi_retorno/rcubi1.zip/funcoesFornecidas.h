#ifndef _funcoesFornecidas_
#define _funcoesFornecidas_

void binarioNaTela(char *nomeArquivoBinario);
void scan_quote_string(char *str);
char* dynamic_scan_quote_string();

#endif
